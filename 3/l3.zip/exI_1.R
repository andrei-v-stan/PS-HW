vol_sfera = function(N){
  N_C = 0;
  for(i in 1:N){
    x = runif(1, -1, 1);
    y = runif(1, -1, 1);
    z = runif(1, -1, 1);
    if(x^2 + y^2 + z^2 <=1)
      N_C = N_C + 1;
  }
  volEstimat = 8*N_C/N;
  volExact = 4*pi/3;
  cat("Volumul estimat:", volEstimat," Volumul exact: ", volExact, "\n");
  cat("Eroarea absoluta:", abs(volExact- volEstimat), "\n");
  cat("Eroarea relativa:", abs(volExact- volEstimat)/volExact);
}
estimareIntegrala = function(N){
  sum = 0;
  for(i in 1:N){
    u = rexp(1, 1);
    sum = sum+ exp(-u^2)/exp(-u);
  }
  return(sum/N);
}

estimareIntegralaAverage = function(k, N){
  estimates = vector();
  for(i in 1:k){
    estimates[i] = estimareIntegrala(N);
  }
  cat("Estimare medie:", mean(estimates), " Deviatia standard:", sd(estimates), "\n");
}

ex_II_1a = function(N){
  sum = 0;
  for(i in 1:N){
    x = runif(1, 0, pi);
    sum = sum+ sin(x)*sin(x);
  }
  cat("Estimarea:", pi*sum/N, " Valoarea exacta: ", pi/2);
}

ex_II_1d = function(a, N){
  sum = 0;
  for(i in 1:N){
    x = runif(1, 1, a);
    sum = sum+ 1/(4*x^2 - 1);
  }
  cat("Estimarea:", (a - 1)*sum/N, " Valoarea exacta: ", log(3)/4);
}


ex_II_2 = function(N){
  sum = 0;
  for(i in 1:N){
    u = rexp(1, 3);
    sum = sum+ exp(-2*u^2)/(3*exp(-3*u));
  }
  cat("Estimarea:", sum/N, " Valoarea exacta: ", sqrt(pi/8));
 # return(sum/N);
  }

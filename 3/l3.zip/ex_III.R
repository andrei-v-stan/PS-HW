nrDays = function(){# ex III.1
  nrDays = 1;
  lastErrors = c(13, 15, 9);
  errors = 13;
  while(errors > 0) {
    lambda = mean(lastErrors);
    errors = rpois(1, lambda);
    lastErrors = c(errors, lastErrors[1], lastErrors[2]);
  #  cat(lastErrors, "\n")
    nrDays = nrDays + 1;
  }
  return(nrDays);
}

MonteCarloNrDays = function(N){
  sum = 0;
  for(i in 1:N){
    sum = sum+ nrDays();
  }
  print(sum/N);
}